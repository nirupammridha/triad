<?php
/**
 * Template Name: Privacy-policy
 * 
 */
get_header(); 
?>

<section class="container-fluid">
	<?=the_content();?>
</section>

<?php
get_footer();