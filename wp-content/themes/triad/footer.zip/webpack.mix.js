// webpack.mix.js

let mix = require('laravel-mix');

mix
.js('src/app.js', 'assets/js')
.sass('src/app.scss', 'assets/css');