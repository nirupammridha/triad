<?php
/**
 * Template Name: Media
 * 
 */
get_header(); 
?>

<section class="container-fluid">
</section>

<?php
get_footer();